from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.workArea = 'CrabBEST'
config.General.requestName = 'GravitonZZ_M_6500GeV_trees'
config.section_('JobType')
config.JobType.psetName = 'config/run_ZZ.py'
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['BESTInputs.root']
config.section_('Data')
config.Data.inputDataset = '/BulkGravToZZToZhadZhad_narrow_M-6500_TuneCP5_13TeV-madgraph-pythia/RunIISummer20UL17MiniAODv2-106X_mc2017_realistic_v9-v2/MINIAODSIM'
config.Data.ignoreLocality = True
config.Data.splitting = 'Automatic'
config.Data.publication = False
config.section_('Site')
config.Site.whitelist = ['T2_US_*']
config.Site.storageSite = 'T3_US_FNALLPC'
