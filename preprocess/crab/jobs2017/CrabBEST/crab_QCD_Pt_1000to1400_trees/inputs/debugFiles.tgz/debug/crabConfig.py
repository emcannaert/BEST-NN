from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.workArea = 'CrabBEST'
config.General.requestName = 'QCD_Pt_1000to1400_trees'
config.section_('JobType')
config.JobType.psetName = 'config/run_QCD.py'
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['BESTInputs.root']
config.section_('Data')
config.Data.inputDataset = '/QCD_Pt_1000to1400_TuneCP5_13TeV_pythia8/RunIISummer20UL17MiniAODv2-106X_mc2017_realistic_v9-v1/MINIAODSIM'
config.Data.publication = False
config.Data.ignoreLocality = True
config.Data.splitting = 'Automatic'
config.Data.totalUnits = 1000000
config.section_('Site')
config.Site.whitelist = ['T2_US_*']
config.Site.storageSite = 'T3_US_FNALLPC'
