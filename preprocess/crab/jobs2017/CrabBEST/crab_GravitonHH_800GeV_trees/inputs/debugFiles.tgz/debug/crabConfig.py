from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.workArea = 'CrabBEST'
config.General.requestName = 'GravitonHH_800GeV_trees'
config.section_('JobType')
config.JobType.psetName = 'config/run_HH.py'
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['BESTInputs.root']
config.section_('Data')
config.Data.inputDataset = '/GluGluToBulkGravitonToHHTo4B_M-800_narrow_TuneCP5_13TeV-madgraph-pythia8/RunIISummer20UL17MiniAOD-106X_mc2017_realistic_v6-v1/MINIAODSIM'
config.Data.ignoreLocality = True
config.Data.splitting = 'Automatic'
config.Data.publication = False
config.section_('Site')
config.Site.whitelist = ['T2_US_*']
config.Site.storageSite = 'T3_US_FNALLPC'
