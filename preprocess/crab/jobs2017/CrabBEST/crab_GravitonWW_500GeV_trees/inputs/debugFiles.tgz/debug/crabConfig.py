from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.workArea = 'CrabBEST'
config.General.requestName = 'GravitonWW_500GeV_trees'
config.section_('JobType')
config.JobType.psetName = 'config/run_WW.py'
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['BESTInputs.root']
config.section_('Data')
config.Data.inputDataset = '/BulkGravToWWToWhadWhad_narrow_M-500_TuneCP5_13TeV-madgraph-pythia/RunIISummer20UL17MiniAOD-106X_mc2017_realistic_v6-v2/MINIAODSIM'
config.Data.ignoreLocality = True
config.Data.splitting = 'Automatic'
config.Data.publication = False
config.section_('Site')
config.Site.whitelist = ['T2_US_*']
config.Site.storageSite = 'T3_US_FNALLPC'
